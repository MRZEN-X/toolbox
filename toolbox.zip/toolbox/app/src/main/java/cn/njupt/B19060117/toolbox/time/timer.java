package cn.njupt.B19060117.toolbox.time;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.TimeZone;

import cn.njupt.B19060117.toolbox.R;


public class timer extends AppWidgetProvider {

    private Calendar calendars;


    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them、
        //使用包名打开vivo 的时钟app
        Intent intent =context.getPackageManager().getLaunchIntentForPackage("com.android.BBKClock");
        //提前的意图
        PendingIntent pi = PendingIntent.getActivity(context,0,intent,0);

        calendars = Calendar.getInstance();
        calendars.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));//东八区
        String year = String.valueOf(calendars.get(Calendar.YEAR));
        String month = String.valueOf(calendars.get(Calendar.MONTH));
        String day = String.valueOf(calendars.get(Calendar.DATE));
        String hour = String.valueOf(calendars.get(Calendar.HOUR));
        String min = String.valueOf(calendars.get(Calendar.MINUTE));
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.timer);

        remoteViews.setOnClickPendingIntent(R.id.timer_btn,pi);
        remoteViews.setTextViewText(R.id.timer_year,year);
        remoteViews.setTextViewText(R.id.timer_month,6+"月");
        remoteViews.setTextViewText(R.id.timer_day,day+"日");
        remoteViews.setTextViewText(R.id.timer_hour,hour+":");
        remoteViews.setTextViewText(R.id.timer_min,min);
        appWidgetManager.updateAppWidget(new ComponentName(context, timer.class),remoteViews);
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

}