package cn.njupt.B19060117.toolbox.mem;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;

public class GetRam {

   //获取总共运存
    public static long getTotalMemorySize(Context context) {
        //sdk大于等于啊安卓7只能使用系统服务获得信息
        if (Build.VERSION.SDK_INT >= 24) {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(memoryInfo);

            return memoryInfo.totalMem;
        } else {
            //sdk小于安卓7有读取proc分区文件的权限可以字节读取。proc不是真正的文件，linux一切皆文件
            String file = "/proc/meminfo";
            try {
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr, 2048);
                String memoryLine = br.readLine();
                String subMemoryLine = memoryLine.substring(memoryLine.indexOf("MemTotal:"));
                br.close();
                return Integer.parseInt(subMemoryLine.replaceAll("\\D+", "")) * 1024l;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return 0;
    }

  //可用ram 使用系统服务获取ram
    public static long getFreeMemory(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(memoryInfo);
        return memoryInfo.availMem;
    }


    //转换成g，安卓是1000进制不知道为什么
    public static double byte2G(long size){

        return  ((double) size / (1000 * 1000 * 1000));
    }
    //设置显示  0.0表示保留1位小数
    public static String showEnd(double free , double all){
        return ((new DecimalFormat("0.0").format(all-free))+"/"+(new DecimalFormat("0.0").format(all+0.1))+"G");
    }

}

