package cn.njupt.B19060117.toolbox.mem;

import android.os.Environment;
import android.os.StatFs;

import java.io.File;
import java.text.DecimalFormat;

public class GetRom {

    private long SD_all,SD_used;//挂载的存储空间
    private long SYS_all,SYS_used;//系统分区+data分区+rec+sys应用

    public void readSDCard() {
        String state = Environment.getExternalStorageState();
        if(Environment.MEDIA_MOUNTED.equals(state)) {
            File sdDir = Environment.getExternalStorageDirectory();
            StatFs sf = new StatFs(sdDir.getPath());
            long blockSize = sf.getBlockSize();
            long blockCount = sf.getBlockCount();
            long usedCount = sf.getAvailableBlocks();
            SD_all = blockSize*blockCount;
            SD_used = (blockCount-usedCount)*blockSize;
        }
    }

   public void readSystem() {
        File root = Environment.getRootDirectory();
        StatFs sf = new StatFs(root.getPath());
        long blockSize = sf.getBlockSize();
        long blockCount = sf.getBlockCount();
        long usedCount = sf.getAvailableBlocks();
        SYS_all = blockCount*blockSize;
        SYS_used = (blockCount-usedCount)*blockSize;
    }

    public String getEnd(){
        readSystem();readSDCard();
        double all  = GetRam.byte2G(SD_all+SYS_all);
        double used = GetRam.byte2G( SD_used+SYS_used);
        return ((new DecimalFormat("0").format(used))+"/"+(new DecimalFormat("0").format(all+1))+"G");
    }
}
