package cn.njupt.B19060117.toolbox.poetry;

public class Poetry {
    private String content;
    private String origin;
    private String author;

    public String getOrigin_author(){
        return origin+"——"+author;
    }

    public String getContent(){
        return  content;
    }
}
