package cn.njupt.B19060117.toolbox.poetry;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetPoetry extends Thread {

    public boolean flag = false;
    public String responseText;

    @Override
    public void run() {
        try {
            URL url = new URL("https://api.gushi.ci/all");
            HttpURLConnection conn=(HttpURLConnection)url.openConnection();
            //get模式
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            //5. 解析is，获取responseText，这里用缓冲字符流
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line=reader.readLine()) != null){
                sb.append(line);
            }
            //获取响应文本
            responseText = String.valueOf(sb.toString());
            is.close();
            System.out.println("子线程执行结束");
            callback();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public  void callback() {
        flag=true;
    }
}


