package cn.njupt.B19060117.toolbox.weather;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetWeather extends Thread {

    public boolean flag = false;
    public String responseText;

    @Override
    public void run() {
        try {
            //1. URL
            URL url = new URL("http://wthrcdn.etouch.cn/weather_mini?city=南京");
            //2. HttpURLConnection
            HttpURLConnection conn=(HttpURLConnection)url.openConnection();
            //3. set(GET)
            conn.setRequestMethod("GET");
            //4. getInputStream
            InputStream is = conn.getInputStream();
            //5. 解析is，获取responseText，这里用缓冲字符流
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line=reader.readLine()) != null){
                sb.append(line);
            }
            //获取响应文本
            responseText = String.valueOf(sb.toString());
            is.close();
            System.out.println("子线程执行结束");
            callback();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public  void callback() {
        flag=true;
    }
}

