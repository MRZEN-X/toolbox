package cn.njupt.B19060117.toolbox.weather;
import java.util.List;

public class WeatherForecast {
    private Data data;
    private int status;
    private String desc;

    public Data getData() {return data;}
    public int getStatus(){return status;}
    public String getDesc(){return desc;}

    public class Data {
        private Yesterday yesterday;
        private String city;
        private List<WeatherInfo> forecast;
        private String ganmao;
        private String wendu;

        public Yesterday getYesterday() {return yesterday;}
        public String getCity() {return city;}
        public List<WeatherInfo> getForecast() {return forecast;}
        public String getGanmao() {return ganmao;}
        public String getWendu(){return wendu;}
    }
    public class Yesterday{
        private String date;
        private String high;
        private String fx;
        private String low;
        private String fl;
        private String type;

        public String getDate() {return date;}
        public String getHigh() {return high;}
        public String getfx(){return fx;}
        public  String getLow() {return low;}
        public String getFl() {return fl;}
        public String getType() {return type;}
    }
    public class WeatherInfo{
        private String date;
        private String high;
        private String fengli;
        private String low;
        private String fengxiang;
        private String type;

        public String getDate(){return date;}
        public String getHigh() {return high;}
        public String getFengli(){return fengli;}
        public String getLow(){return low;}
        public String getFengxiang(){return fengxiang;}
        public String getType(){return type;}
    }
}
