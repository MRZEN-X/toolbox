package cn.njupt.B19060117.toolbox.weather;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.google.gson.Gson;

import java.util.List;

import cn.njupt.B19060117.toolbox.R;

public class Weather_activity extends AppCompatActivity {

    Gson gson;
    WeatherForecast wf1;
    private TextView d_1_date,d_1_high,d_1_fx,d_1_low,d_1_type;
    private TextView a_0_date,a_0_high,a_0_fx,a_0_low,a_0_type,ganmao,wendu;
    private TextView a_1_date,a_1_high,a_1_fx,a_1_low,a_1_type;
    private TextView a_2_date,a_2_high,a_2_fx,a_2_low,a_2_type;
    private TextView a_3_date,a_3_high,a_3_fx,a_3_low,a_3_type;
    private TextView a_4_date,a_4_high,a_4_fx,a_4_low,a_4_type;
    private ImageView d_1_icon,a_1_icon,a_2_icon,a_3_icon,a_4_icon;

    private View d_1,a_0,a_1,a_2,a_3,a_4;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);



        gson = new Gson();
        wf1 = gson.fromJson(getJson(), WeatherForecast.class);

        d_1 = findViewById(R.id.d_1);
        a_0 = findViewById(R.id.add_0);
        a_1 = findViewById(R.id.add_1);
        a_2 = findViewById(R.id.add_2);
        a_3 = findViewById(R.id.add_3);
        a_4 = findViewById(R.id.add_4);

        d_1_date = findViewById(R.id.d_1_date);
        d_1_high = findViewById(R.id.d_1_high);
        d_1_fx   = findViewById(R.id.d_1_fx);
        d_1_low  = findViewById(R.id.d_1_low);
        d_1_type = findViewById(R.id.d_1_type);
        d_1_icon = findViewById(R.id.d_1_icon);

        a_0_date = findViewById(R.id.add_0_date);
        a_0_high = findViewById(R.id.add_0_high);
        a_0_fx   = findViewById(R.id.add_0_fx);
        a_0_low  = findViewById(R.id.add_0_low);
        a_0_type = findViewById(R.id.add_0_type);
        ganmao   = findViewById(R.id.ganmao);
        wendu    = findViewById(R.id.wendu);

        a_1_date = findViewById(R.id.add_1_date);
        a_1_high = findViewById(R.id.add_1_high);
        a_1_fx   = findViewById(R.id.add_1_fx);
        a_1_low  = findViewById(R.id.add_1_low);
        a_1_type = findViewById(R.id.add_1_type);
        a_1_icon = findViewById(R.id.add_1_icon);

        a_2_date = findViewById(R.id.add_2_date);
        a_2_high = findViewById(R.id.add_2_high);
        a_2_fx   = findViewById(R.id.add_2_fx);
        a_2_low  = findViewById(R.id.add_2_low);
        a_2_type = findViewById(R.id.add_2_type);
        a_2_icon = findViewById(R.id.add_2_icon);

        a_3_date = findViewById(R.id.add_3_date);
        a_3_high = findViewById(R.id.add_3_high);
        a_3_fx   = findViewById(R.id.add_3_fx);
        a_3_low  = findViewById(R.id.add_3_low);
        a_3_type = findViewById(R.id.add_3_type);
        a_3_icon = findViewById(R.id.add_3_icon);

        a_4_date = findViewById(R.id.add_4_date);
        a_4_high = findViewById(R.id.add_4_high);
        a_4_fx   = findViewById(R.id.add_4_fx);
        a_4_low  = findViewById(R.id.add_4_low);
        a_4_type = findViewById(R.id.add_4_type);
        a_4_icon = findViewById(R.id.add_4_icon);





        List<WeatherForecast.WeatherInfo> wi = wf1.getData().getForecast();

        d_1_date.setText(wf1.getData().getYesterday().getDate());
        d_1_high.setText(wf1.getData().getYesterday().getHigh());
        d_1_fx.setText(wf1.getData().getYesterday().getfx()+wf1.getData().getYesterday().getFl().substring(9,11));
        d_1_low.setText(wf1.getData().getYesterday().getLow());
        d_1_type.setText(wf1.getData().getYesterday().getType());

        a_0_date.setText(wf1.getData().getForecast().get(0).getDate());
        a_0_high.setText(wf1.getData().getForecast().get(0).getHigh());
        a_0_fx.setText(wf1.getData().getForecast().get(0).getFengxiang()+wf1.getData().getForecast().get(0).getFengli().substring(9,11));
        a_0_low.setText(wf1.getData().getForecast().get(0).getLow());
        a_0_type.setText(wf1.getData().getForecast().get(0).getType());
        ganmao.setText(wf1.getData().getGanmao());
        wendu.setText("当前"+wf1.getData().getWendu()+"℃");

        a_1_date.setText(wf1.getData().getForecast().get(1).getDate());
        a_1_high.setText(wf1.getData().getForecast().get(1).getHigh());
        a_1_fx.setText(wf1.getData().getForecast().get(1).getFengxiang()+wf1.getData().getForecast().get(1).getFengli().substring(9,11));
        a_1_low.setText(wf1.getData().getForecast().get(1).getLow());
        a_1_type.setText(wf1.getData().getForecast().get(1).getType());

        a_2_date.setText(wf1.getData().getForecast().get(2).getDate());
        a_2_high.setText(wf1.getData().getForecast().get(2).getHigh());
        a_2_fx.setText(wf1.getData().getForecast().get(2).getFengxiang()+wf1.getData().getForecast().get(2).getFengli().substring(9,11));
        a_2_low.setText(wf1.getData().getForecast().get(2).getLow());
        a_2_type.setText(wf1.getData().getForecast().get(2).getType());

        a_3_date.setText(wf1.getData().getForecast().get(3).getDate());
        a_3_high.setText(wf1.getData().getForecast().get(3).getHigh());
        a_3_fx.setText(wf1.getData().getForecast().get(3).getFengxiang()+wf1.getData().getForecast().get(3).getFengli().substring(9,11));
        a_3_low.setText(wf1.getData().getForecast().get(3).getLow());
        a_3_type.setText(wf1.getData().getForecast().get(3).getType());

        a_4_date.setText(wf1.getData().getForecast().get(4).getDate());
        a_4_high.setText(wf1.getData().getForecast().get(4).getHigh());
        a_4_fx.setText(wf1.getData().getForecast().get(4).getFengxiang()+wf1.getData().getForecast().get(4).getFengli().substring(9,11));
        a_4_low.setText(wf1.getData().getForecast().get(4).getLow());
        a_4_type.setText(wf1.getData().getForecast().get(4).getType());

        setDayBackground(d_1,d_1_icon,d_1_type);
        setDayBackground(a_0,a_4_icon,a_0_type);
        setDayBackground(a_1,a_1_icon,a_1_type);
        setDayBackground(a_2,a_2_icon,a_2_type);
        setDayBackground(a_3,a_3_icon,a_3_type);
        setDayBackground(a_4,a_4_icon,a_4_type);


    }

    void setDayBackground(View view, ImageView image, TextView type){
        if(type.getText().equals("多云")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.duoyun,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.duoyun_icon,null));
        }
        if(type.getText().equals("晴")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.qintian,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.qintian_icon,null));
        }
        if(type.getText().equals("小雨")||type.getText().equals("小到中雨")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.xiaoyu,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.xiaoyu_icon,null));
        }
        if(type.getText().equals("中雨")||type.getText().equals("中到大雨")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.zhongyu,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.zhongyu_icon,null));
        }
        if(type.getText().equals("大雨")||type.getText().equals("大到暴雨")||type.getText().equals("暴雨")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.dayu,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.dayu_icon,null));
        }
        if(type.getText().equals("阴")){
            view.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.yintian,null));
            image.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.yintian_icon,null));
        }
    }

    public static String getJson() {
        GetWeather gw =new GetWeather();
        gw.start();
        while(gw.flag==false){
            System.out.println("子线程执行中"+gw.flag);
        }
        return gw.responseText;
    }
}