package cn.njupt.B19060117.toolbox.mem;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;
import android.widget.Toast;

import cn.njupt.B19060117.toolbox.R;


public class men_widget extends AppWidgetProvider {



    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        //ram 数据
        double ram_all = GetRam.byte2G(GetRam.getTotalMemorySize(context));
        double ram_free = GetRam.byte2G(GetRam.getFreeMemory(context));
        RemoteViews rv = new RemoteViews(context.getPackageName(),R.layout.men_widget);
        rv.setTextViewText(R.id.ram_use, GetRam.showEnd(ram_free,ram_all));
        //rom 数据
        rv.setTextViewText(R.id.rom_use, new GetRom().getEnd());
        Toast.makeText(context,"mem更新",Toast.LENGTH_SHORT).show();
        appWidgetManager.updateAppWidget(new ComponentName(context, men_widget.class),rv);
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created

    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }


}

