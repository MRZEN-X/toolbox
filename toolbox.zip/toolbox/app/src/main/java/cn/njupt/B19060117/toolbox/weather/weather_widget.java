package cn.njupt.B19060117.toolbox.weather;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.google.gson.Gson;

import cn.njupt.B19060117.toolbox.R;

/**
 * Implementation of App Widget functionality.
 */
public class weather_widget extends AppWidgetProvider {


    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        Toast.makeText(context,"创建天气小部件成功",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Intent intent=new Intent(context, Weather_activity.class);
        PendingIntent pendingIntent=PendingIntent.getActivity(context, 0, intent, 0);


        Gson gson = new Gson();
        WeatherForecast wf = gson.fromJson(getJson(), WeatherForecast.class);

        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.weather_widget);

        remoteViews.setOnClickPendingIntent(R.id.weather_btn,pendingIntent);

        remoteViews.setTextViewText(R.id.weather_type,  wf.getData().getForecast().get(0).getType());
        remoteViews.setTextViewText(R.id.weather_h,  wf.getData().getForecast().get(0).getHigh());
        remoteViews.setTextViewText(R.id.weather_l,  wf.getData().getForecast().get(0).getLow());
        remoteViews.setTextViewText(R.id.weather_t,  "当前"+wf.getData().getWendu()+"°C");
        remoteViews.setTextViewText(R.id.weather_tip,  wf.getData().getGanmao());
        Toast.makeText(context,wf.getData().getForecast().get(0).getType(),Toast.LENGTH_SHORT).show();
        appWidgetManager.updateAppWidget(new ComponentName(context,weather_widget.class),remoteViews);
    }


    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }


    public static String getJson() {
        GetWeather gw =new GetWeather();
        gw.start();
        while(gw.flag==false){
            System.out.println("子线程执行中"+gw.flag);
        }
        return gw.responseText;
    }

}