package cn.njupt.B19060117.toolbox.poetry;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.google.gson.Gson;

import cn.njupt.B19060117.toolbox.R;

/**
 * Implementation of App Widget functionality.
 */
public class poetry_widget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        Gson gson = new Gson();
        Poetry p = gson.fromJson(getJson(), Poetry.class);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.poetry_widget);
        remoteViews.setTextViewText(R.id.poetry_ao,  p.getOrigin_author());
        remoteViews.setTextViewText(R.id.poetry_content,  p.getContent());
        appWidgetManager.updateAppWidget(new ComponentName(context, poetry_widget.class),remoteViews);
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
        Toast.makeText(context,"每日诗词",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    public static String getJson() {
        GetPoetry gp =new GetPoetry();
        gp.start();
        while(gp.flag==false){
            System.out.println("子线程执行中"+gp.flag);
        }
        return gp.responseText;
    }
}